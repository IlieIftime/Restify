# pip install torch transformers librosa matplotlib
import torch
from transformers import WavLMConfig, WavLMForSequenceClassification, AutoFeatureExtractor
import librosa
import matplotlib.pyplot as plt
import numpy as np

# 1. Configurações
AUDIO_PATH = r"C:\Users\iliei\OneDrive - ISCTE-IUL\Ambiente de Trabalho\Universidade 2º ano\2º Semestre\Empreendedorimos e Inovaçao II\RestifyV2\ml\snoreVSapneiaSound.mp3"
MODEL_NAME = "microsoft/wavlm-base-plus"
CLASSES = ["Apneia", "Ronco", "Fala", "Ruído de Fundo"]  # Suas categorias personalizadas


# 2. Carregar modelo com cabeçalho personalizado
def load_custom_model():
    try:
        print("⏳ Configurando modelo personalizado...")

        # Configuração com número de classes personalizado
        config = WavLMConfig.from_pretrained(MODEL_NAME)
        config.num_labels = len(CLASSES)

        # Carrega arquitetura com pesos pretreinados
        model = WavLMForSequenceClassification.from_pretrained(
            MODEL_NAME,
            config=config,
            ignore_mismatched_sizes=True
        )

        # Configura dispositivo
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model.to(device)
        model.eval()

        print(f"✅ Modelo carregado em {device} | Classes: {len(CLASSES)}")
        return model, AutoFeatureExtractor.from_pretrained(MODEL_NAME), device

    except Exception as e:
        print(f"❌ Erro no modelo: {e}")
        raise


# 3. Pré-processamento de áudio
def preprocess_audio(file_path, feature_extractor):
    try:
        waveform, sr = librosa.load(file_path, sr=16000, mono=True)
        inputs = feature_extractor(
            waveform,
            sampling_rate=sr,
            return_tensors="pt",
            padding="max_length",
            max_length=16000 * 5,  # 5 segundos
            truncation=True
        )
        return inputs, sr
    except Exception as e:
        print(f"❌ Erro no áudio: {e}")
        raise


# 4. Classificação e visualização
def analyze(model, feature_extractor, device):
    try:
        # Pré-processamento
        inputs, _ = preprocess_audio(AUDIO_PATH, feature_extractor)
        inputs = {k: v.to(device) for k, v in inputs.items()}

        # Inferência
        with torch.no_grad():
            outputs = model(**inputs)

        # Processamento dos resultados
        probs = torch.nn.functional.softmax(outputs.logits, dim=-1)
        results = {CLASSES[i]: float(probs[0][i]) for i in range(len(CLASSES))}

        # Plot
        plt.figure(figsize=(10, 5))
        plt.bar(results.keys(), results.values(), color='skyblue')
        plt.title("Probabilidades por Classe")
        plt.ylabel("Probabilidade")
        plt.ylim(0, 1)
        plt.savefig("resultados_personalizados.png")

        print("\n📊 Resultados:")
        for classe, prob in results.items():
            print(f"- {classe}: {prob * 100:.2f}%")
        print("\n📈 Gráfico salvo como 'resultados_personalizados.png'")

    except Exception as e:
        print(f"❌ Erro na análise: {e}")


# 5. Execução principal
if __name__ == "__main__":
    try:
        model, feature_extractor, device = load_custom_model()
        analyze(model, feature_extractor, device)
    except Exception as e:
        print(f"❌ Falha crítica: {e}")