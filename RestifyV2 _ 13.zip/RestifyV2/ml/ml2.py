# pip install torch transformers librosa matplotlib numpy
import torch
from transformers import AutoFeatureExtractor, AutoModelForAudioClassification
import librosa
import matplotlib.pyplot as plt
import numpy as np
import os

# Configurações globais
SAMPLE_RATE = 16000  # Taxa de amostragem exigida pelo WavLM
SEGMENT_DURATION = 5  # Duração de cada segmento em segundos
CLASS_NAMES = ["Normal", "Ronco", "Apneia"]  # Classes simplificadas
MODEL_NAME = "microsoft/wavlm-base-plus-sv"  # Modelo otimizado para análise de voz


def load_model():
    """Carrega o modelo e o feature extractor do Hugging Face"""
    try:
        print("⏳ Carregando modelo...")

        # Verifica se há GPU disponível
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Dispositivo selecionado: {device}")

        # Carrega os componentes
        feature_extractor = AutoFeatureExtractor.from_pretrained(MODEL_NAME)
        model = AutoModelForAudioClassification.from_pretrained(MODEL_NAME).to(device)

        # Ajusta para 3 classes de saída
        model.config.num_labels = len(CLASS_NAMES)
        model.classifier = torch.nn.Linear(model.classifier.in_features, len(CLASS_NAMES)).to(device)

        model.eval()
        print("✅ Modelo carregado com sucesso!")
        return feature_extractor, model, device

    except Exception as e:
        print(f"❌ Erro ao carregar modelo: {e}")
        raise


def preprocess_audio(audio_path):
    """Carrega e pré-processa o áudio com verificações"""
    try:
        print(f"🔊 Processando: {os.path.basename(audio_path)}")

        # Verifica se o arquivo existe
        if not os.path.exists(audio_path):
            raise FileNotFoundError(f"Arquivo não encontrado: {audio_path}")

        # Carrega o áudio
        signal, sr = librosa.load(audio_path, sr=SAMPLE_RATE, mono=True)

        # Verifica qualidade do áudio
        if len(signal) < SAMPLE_RATE * 0.5:  # Mínimo 0.5 segundos
            raise ValueError("Áudio muito curto para análise")

        # Normalização e remoção de silêncio
        signal = librosa.util.normalize(signal)
        signal, _ = librosa.effects.trim(signal, top_db=20)

        return signal, sr

    except Exception as e:
        print(f"❌ Erro no pré-processamento: {e}")
        raise


def analyze_audio(audio_path, feature_extractor, model, device):
    """Executa a análise completa do áudio"""
    try:
        # Pré-processamento
        signal, sr = preprocess_audio(audio_path)

        # Divide em segmentos
        segment_length = SEGMENT_DURATION * sr
        segments = [signal[i:i + segment_length] for i in range(0, len(signal), segment_length)]

        # Remove segmento final se muito curto
        if len(segments[-1]) < segment_length * 0.8:
            segments = segments[:-1]

        print(f"📊 Analisando {len(segments)} segmentos...")

        # Classificação
        results = []
        for i, segment in enumerate(segments):
            inputs = feature_extractor(
                segment,
                sampling_rate=sr,
                return_tensors="pt",
                padding="max_length",
                max_length=segment_length,
                truncation=True
            ).to(device)

            with torch.no_grad():
                outputs = model(**inputs)

            pred = torch.argmax(outputs.logits).item()
            results.append(pred)

            # Exibe progresso
            if (i + 1) % 5 == 0 or (i + 1) == len(segments):
                print(f"Segmento {i + 1}/{len(segments)}: {CLASS_NAMES[pred]}")

        return results

    except Exception as e:
        print(f"❌ Erro na análise: {e}")
        raise


def generate_report(results, audio_name):
    """Gera relatório visual dos resultados"""
    try:
        # Contagem por classe
        counts = {name: results.count(i) for i, name in enumerate(CLASS_NAMES)}
        total = len(results)

        # Gráfico
        plt.figure(figsize=(12, 6))

        # Gráfico de barras
        plt.subplot(1, 2, 1)
        plt.bar(counts.keys(), counts.values(), color=['green', 'orange', 'red'])
        plt.title("Distribuição de Eventos")
        plt.ylabel("Número de Segmentos")

        # Gráfico temporal
        plt.subplot(1, 2, 2)
        time_axis = [i * SEGMENT_DURATION for i in range(len(results))]
        colors = ['green' if r == 0 else 'orange' if r == 1 else 'red' for r in results]
        plt.scatter(time_axis, results, c=colors, alpha=0.7)
        plt.yticks(range(len(CLASS_NAMES)), CLASS_NAMES)
        plt.xlabel("Tempo (segundos)")
        plt.title("Linha Temporal")

        plt.tight_layout()

        # Salva o relatório
        os.makedirs("relatorios", exist_ok=True)
        output_path = f"relatorios/{audio_name}_analise.png"
        plt.savefig(output_path, dpi=120)
        plt.close()

        print(f"\n📈 Relatório salvo em: {output_path}")

        # Retorna estatísticas
        stats = {
            "total_segmentos": total,
            "percentual_ronco": f"{100 * counts['Ronco'] / total:.1f}%",
            "percentual_apneia": f"{100 * counts['Apneia'] / total:.1f}%",
            "arquivo": output_path
        }

        return stats

    except Exception as e:
        print(f"⚠️ Erro ao gerar relatório: {e}")
        return None


def main():
    """Função principal"""
    try:
        # Carrega o modelo
        feature_extractor, model, device = load_model()

        # Arquivo de áudio para análise
        audio_path = r"C:\Users\iliei\OneDrive - ISCTE-IUL\Ambiente de Trabalho\Universidade 2º ano\2º Semestre\Empreendedorimos e Inovaçao II\RestifyV2\ml\snoreVSapneiaSound.mp3"
        audio_name = os.path.splitext(os.path.basename(audio_path))[0]

        if not os.path.exists(audio_path):
            raise FileNotFoundError(f"Arquivo não encontrado: {audio_path}")

        # Executa análise
        print("\n" + "=" * 60)
        print(f"🔍 Iniciando análise do arquivo: {audio_name}")
        print("=" * 60)

        results = analyze_audio(audio_path, feature_extractor, model, device)

        # Gera relatório
        stats = generate_report(results, audio_name)

        # Exibe resumo
        print("\n📋 Resultado Final:")
        print(
            f"Total analisado: {stats['total_segmentos']} segmentos ({stats['total_segmentos'] * SEGMENT_DURATION} segundos)")
        print(f"Ronco detectado: {stats['percentual_ronco']}")
        print(f"Apneia detectada: {stats['percentual_apneia']}")
        print(f"Visualize o relatório completo em: {stats['arquivo']}")

    except Exception as e:
        print(f"❌ Falha na execução: {e}")


if __name__ == "__main__":
    main()