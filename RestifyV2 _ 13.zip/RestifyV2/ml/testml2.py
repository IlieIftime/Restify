"""Referências Científicas Incorporadas:
1. Ronco:
   - Faixa de frequência: 40-300 Hz (Herzog et al., 2008)
   - Energia típica: > -25 dB na banda de ronco
   - Zero Crossing Rate < 0.1 (Ben-Israel et al., 2012)

2. Apneia:
   - Pausas > 10 segundos (Padrão AASM)
   - Queda de energia > 10 dB durante eventos
   - Recuperação pós-apneia com aumento súbito de energia"""

from transformers import pipeline
import librosa
import numpy as np
from scipy import signal
import os
import matplotlib.pyplot as plt

# Configurações baseadas em evidências clínicas
model_name = "audeering/wav2vec2-large-robust-12-ft-emotion-msp-dim"
mp3_path = r"C:\Users\iliei\OneDrive - ISCTE-IUL\Ambiente de Trabalho\Universidade 2º ano\2º Semestre\Empreendedorimos e Inovaçao II\RestifyV2\ml\apneiaSample2.mp3"

# Parâmetros clínicos (baseados em estudos)
SNORE_FREQ_RANGE = (40, 300)  # Hz
APNEA_PAUSE_THRESHOLD = 10  # segundos
ENERGY_THRESHOLD = -25  # dB
ZCR_THRESHOLD = 0.1  # Zero Crossing Rate

CUSTOM_LABELS = {
    0: "Respiração Normal",
    1: "Ronco",
    2: "Apneia",
    3: "Outro Som Respiratório"
}


def load_and_preprocess_audio(file_path):
    #Carrega e filtra o áudio na banda de ronco
    try:
        y, sr = librosa.load(file_path, sr=16000, mono=True)

        # Filtro passa-banda para ronco (40-300Hz)
        sos = signal.butter(10, SNORE_FREQ_RANGE, btype='bandpass', fs=sr, output='sos')
        y_filtered = signal.sosfilt(sos, y)

        # Limita a 5 minutos (para processamento)
        max_samples = 16000 * 300
        if len(y) > max_samples:
            y = y[:max_samples]
            y_filtered = y_filtered[:max_samples]

        return y, y_filtered, sr
    except Exception as e:
        print(f"Erro no pré-processamento: {e}")
        return None, None, None


def extract_clinical_features(y, y_filtered, sr):
    #Extrai métricas clínicas baseadas em literatura
    # Análise de Ronco
    D = librosa.amplitude_to_db(np.abs(librosa.stft(y_filtered)), ref=np.max)
    freq_mask = (librosa.fft_frequencies(sr=sr) >= SNORE_FREQ_RANGE[0]) & \
                (librosa.fft_frequencies(sr=sr) <= SNORE_FREQ_RANGE[1])
    snore_energy = np.mean(D[freq_mask, :])

    # Detecção de Apneia
    rms = librosa.feature.rms(y=y)[0]
    silence_threshold = np.percentile(rms, 10)
    pauses = rms < silence_threshold
    pause_duration = np.sum(pauses) * (len(y) / sr) / len(rms)

    # Métricas adicionais
    zcr = librosa.feature.zero_crossing_rate(y=y)[0]
    spectral_centroid = librosa.feature.spectral_centroid(y=y, sr=sr)[0]

    return {
        'snore_energy': snore_energy,
        'pause_duration': pause_duration,
        'zero_crossing_rate': np.mean(zcr),
        'spectral_centroid': np.mean(spectral_centroid),
        'is_snore': snore_energy > ENERGY_THRESHOLD and np.mean(zcr) < ZCR_THRESHOLD,
        'is_apnea': pause_duration >= APNEA_PAUSE_THRESHOLD
    }


def plot_medical_analysis(y, y_filtered, sr, features):
    #Visualização dos padrões clínicos
    plt.figure(figsize=(15, 10))

    # Forma de onda
    plt.subplot(3, 1, 1)
    librosa.display.waveshow(y, sr=sr)
    plt.title("Forma de Onda Original")

    # Espectrograma filtrado
    plt.subplot(3, 1, 2)
    D = librosa.amplitude_to_db(np.abs(librosa.stft(y_filtered)), ref=np.max)
    librosa.display.specshow(D, y_axis='log', x_axis='time')
    plt.axhline(SNORE_FREQ_RANGE[0], color='r', linestyle='--')
    plt.axhline(SNORE_FREQ_RANGE[1], color='r', linestyle='--')
    plt.title(f"Espectrograma na Banda de Ronco ({SNORE_FREQ_RANGE[0]}-{SNORE_FREQ_RANGE[1]} Hz)")

    # Energia RMS
    plt.subplot(3, 1, 3)
    rms = librosa.feature.rms(y=y)[0]
    times = librosa.times_like(rms, sr=sr)
    plt.plot(times, rms)
    plt.axhline(np.percentile(rms, 10), color='r', linestyle='--')
    plt.title("Energia RMS (Detecção de Pausas)")

    plt.tight_layout()
    plt.show()


def classify_with_ml(y):
    #Classificação com modelo de Machine Learning
    try:
        classifier = pipeline(
            "audio-classification",
            model=model_name
        )
        classifier.model.config.id2label = CUSTOM_LABELS
        return classifier(y)
    except Exception as e:
        print(f"Erro na classificação por ML: {e}")
        return None


def print_diagnostic_report(features, ml_results):
    #Gera relatório integrado
    print("\n📊 Relatório Clínico Integrado")
    print("=" * 50)

    # Métricas clínicas
    print("\n🔍 Métricas Baseadas em Evidências:")
    print(
        f"- Energia na banda de ronco (40-300Hz): {features['snore_energy']:.2f} dB {'(ALERTA)' if features['is_snore'] else ''}")
    print(f"- Duração de pausas: {features['pause_duration']:.2f}s {'(APNEIA)' if features['is_apnea'] else ''}")
    print(f"- Taxa de cruzamento por zero: {features['zero_crossing_rate']:.3f}")
    print(f"- Centróide espectral: {features['spectral_centroid']:.2f} Hz")

    # Interpretação ML
    if ml_results:
        print("\n🤖 Classificação por IA:")
        for i, res in enumerate(ml_results[:3], 1):
            print(f"{i}. {res['label']}: {res['score']:.2%}")

    # Recomendações
    print("\n🩺 Recomendações:")
    if features['is_apnea']:
        print("- Padrão de APNEIA detectado. Consulte um especialista em sono.")
    elif features['is_snore']:
        print("- Padrão de RONCO detectado. Monitorar frequência e intensidade.")
    else:
        print("- Padrão dentro dos limites normais.")


if __name__ == "__main__":
    if not os.path.exists(mp3_path):
        print(f"❌ Arquivo não encontrado: {mp3_path}")
        exit()

    print(f"\n🔬 Análise Avançada de: {os.path.basename(mp3_path)}")

    # 1. Pré-processamento clínico
    y, y_filtered, sr = load_and_preprocess_audio(mp3_path)
    if y is None:
        exit()

    # 2. Extração de features clínicas
    features = extract_clinical_features(y, y_filtered, sr)

    # 3. Classificação por ML
    ml_results = classify_with_ml(y)

    # 4. Relatório integrado
    print_diagnostic_report(features, ml_results)

    # 5. Visualização (opcional)
    #plot_medical_analysis(y, y_filtered, sr, features)