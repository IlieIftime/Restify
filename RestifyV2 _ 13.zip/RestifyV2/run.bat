@echo off
start "" /b python run.py
exit