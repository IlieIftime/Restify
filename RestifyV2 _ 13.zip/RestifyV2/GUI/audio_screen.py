import tkinter as tk
from tkinter import filedialog, Listbox, messagebox
from PIL import Image, ImageTk
import pygame
import os


class AudioScreen:
    def __init__(self, root):
        self.root = root
        self.root.title("Gerenciar Áudio - Restify")
        self.root.geometry("1200x1200")
        self.root.resizable(False, False)

        # Inicializar mixer do pygame para reprodução de áudio
        pygame.mixer.init()

        # Aplicar imagem de fundo
        self.set_background()

        # Exibir logo
        self.show_logo()

        # Criar interface
        self.create_interface()

    def set_background(self):
        """Define a imagem de fundo."""
        try:
            img = Image.open("img/img.png").resize((1200, 1200), Image.LANCZOS)
            self.bg_photo = ImageTk.PhotoImage(img)
            label_fundo = tk.Label(self.root, image=self.bg_photo)
            label_fundo.place(x=0, y=0, relwidth=1, relheight=1)
        except Exception as e:
            print(f"Erro ao carregar imagem de fundo: {e}")

    def show_logo(self):
        """Exibe o logo centralizado no topo."""
        try:
            logo = Image.open("img/logo.png").resize((200, 200), Image.LANCZOS)
            self.logo_photo = ImageTk.PhotoImage(logo)
            label_logo = tk.Label(self.root, image=self.logo_photo, bg='white')
            label_logo.place(x=500, y=0)
        except Exception as e:
            print(f"Erro ao carregar logo: {e}")

    def create_interface(self):
        """Cria os botões e lista de áudios em disposição vertical."""
        # Botão Carregar Áudio
        btn_upload = tk.Button(self.root, text="Carregar Áudio", font=("Arial", 14), bg='white',
                               fg='black', padx=20, pady=10, bd=2, relief="raised", command=self.upload_audio)
        btn_upload.place(relx=0.5, rely=0.2, anchor="center", width=200, height=50)

        # Lista de áudios com scrollbar
        list_frame = tk.Frame(self.root)
        list_frame.place(relx=0.5, rely=0.4, anchor="center", width=500, height=300)

        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.listbox = Listbox(list_frame, font=("Arial", 14), width=40, height=10,
                               yscrollcommand=scrollbar.set, selectmode=tk.EXTENDED)
        self.listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.listbox.yview)

        # Checkbox para selecionar todos
        self.select_all_var = tk.IntVar()
        chk_select_all = tk.Checkbutton(self.root, text="Selecionar Todos", font=("Arial", 12),
                                        variable=self.select_all_var, command=self.toggle_select_all)
        chk_select_all.place(relx=0.5, rely=0.55, anchor="center")

        # Botão Eliminar Áudio
        btn_delete = tk.Button(self.root, text="Eliminar Áudio", font=("Arial", 14), bg='white',
                               fg='black', padx=20, pady=10, bd=2, relief="raised", command=self.delete_audio)
        btn_delete.place(relx=0.5, rely=0.67, anchor="center", width=200, height=50)

        # Botão Reproduzir Áudio
        btn_play = tk.Button(self.root, text="Reproduzir Áudio", font=("Arial", 14), bg='white',
                             fg='black', padx=20, pady=10, bd=2, relief="raised", command=self.play_audio)
        btn_play.place(relx=0.5, rely=0.6, anchor="center", width=200, height=50)

        # Botão Parar Áudio
        btn_stop = tk.Button(self.root, text="Parar Áudio", font=("Arial", 14), bg='white',
                             fg='black', padx=20, pady=10, bd=2, relief="raised", command=self.stop_audio)
        btn_stop.place(relx=0.5, rely=0.73, anchor="center", width=200, height=50)

        # Botão Voltar
        btn_back = tk.Button(self.root, text="Voltar", font=("Arial", 14), bg='white',
                             fg='black', padx=20, pady=10, bd=2, relief="raised", command=self.go_back)
        btn_back.place(relx=0.5, rely=0.8, anchor="center", width=200, height=50)

        self.load_audio_list()

    def toggle_select_all(self):
        """Seleciona ou deseleciona todos os itens na listbox."""
        if self.select_all_var.get():
            self.listbox.selection_set(0, tk.END)
        else:
            self.listbox.selection_clear(0, tk.END)

    def upload_audio(self):
        """Permite selecionar um arquivo de áudio e armazená-lo na pasta."""
        file_path = filedialog.askopenfilename(filetypes=[("Audio Files", "*.mp3;*.wav")])
        if file_path:
            file_name = os.path.basename(file_path)
            dest_path = os.path.join("audio_records", file_name)

            # Verifica se o arquivo já existe
            if os.path.exists(dest_path):
                messagebox.showwarning("Aviso", "Um arquivo com esse nome já existe!")
                return

            os.rename(file_path, dest_path)
            self.load_audio_list()

    def load_audio_list(self):
        """Carrega a lista de arquivos de áudio disponíveis."""
        self.listbox.delete(0, tk.END)
        if not os.path.exists("audio_records"):
            os.makedirs("audio_records")

        for file in os.listdir("audio_records"):
            if file.endswith(".mp3") or file.endswith(".wav"):
                self.listbox.insert(tk.END, file)

    def play_audio(self):
        """Reproduz o áudio selecionado na lista."""
        selected_items = self.listbox.curselection()
        if not selected_items:
            messagebox.showwarning("Aviso", "Por favor, selecione um áudio para reproduzir!")
            return

        # Reproduz apenas o primeiro item selecionado
        selected_audio = self.listbox.get(selected_items[0])
        audio_path = os.path.join("audio_records", selected_audio)
        pygame.mixer.music.load(audio_path)
        pygame.mixer.music.play()

    def stop_audio(self):
        """Para a reprodução do áudio atual."""
        pygame.mixer.music.stop()

    def delete_audio(self):
        """Elimina os áudios selecionados."""
        selected_items = self.listbox.curselection()
        if not selected_items:
            messagebox.showwarning("Aviso", "Por favor, selecione pelo menos um áudio para eliminar!")
            return

        confirm = messagebox.askyesno("Confirmar", "Tem certeza que deseja eliminar os áudios selecionados?")
        if confirm:
            # Elimina do mais recente para o mais antigo para evitar problemas com índices
            for index in reversed(selected_items):
                file_name = self.listbox.get(index)
                file_path = os.path.join("audio_records", file_name)
                try:
                    os.remove(file_path)
                except Exception as e:
                    messagebox.showerror("Erro", f"Não foi possível eliminar {file_name}: {str(e)}")

            self.load_audio_list()
            self.select_all_var.set(0)  # Desmarca o checkbox "Selecionar Todos"

    def go_back(self):
        """Retorna ao menu inicial."""
        from GUI.menu_screen import MenuScreen
        self.stop_audio()  # Para qualquer áudio que esteja tocando
        for widget in self.root.winfo_children():
            widget.destroy()
        MenuScreen(self.root)


if __name__ == "__main__":
    root = tk.Tk()
    app = AudioScreen(root)
    root.mainloop()