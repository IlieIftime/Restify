#pip install torch
#pip install transformers
#pip install librosa
#pip install matplotlib
from transformers import Wav2Vec2Processor, WavLMForSequenceClassification
import torch
import librosa
import matplotlib.pyplot as plt

# Carregar processador e modelo pré-treinado
processor = Wav2Vec2Processor.from_pretrained("microsoft/wavlm-base-plus")
model = WavLMForSequenceClassification.from_pretrained("microsoft/wavlm-base-plus")

# Função para pré-processar o áudio
def preprocess_audio(audio_path):
    # Carregar áudio com sample rate de 16kHz
    signal, sr = librosa.load(audio_path, sr=16000)
    # Criar batch de entrada para o modelo
    inputs = processor(signal, sampling_rate=16000, return_tensors="pt", padding=True)
    return inputs

# Função para classificar o som
def classify_sound(audio_path):
    inputs = preprocess_audio(audio_path)
    with torch.no_grad():
        outputs = model(**inputs)
    logits = outputs.logits
    predicted_class = torch.argmax(logits, dim=-1).item()
    return predicted_class

# Função para gerar gráficos a partir dos resultados
def plot_results(results):
    classes = ["Ronco", "Apneia", "Silêncio"]  # Exemplo de classes
    plt.bar(classes, results)
    plt.xlabel("Classes")
    plt.ylabel("Ocorrências")
    plt.title("Classificação de Som")
    plt.savefig("results_plot.png")

# Fluxo completo para processar um áudio e gerar o gráfico
if __name__ == "__main__":
    audio_path = "exemplo_audio.wav"
    # Classificação simulada
    result = classify_sound(audio_path)
    print(f"Classe Predita: {result}")

    # Resultados simulados para plot (substituir pelos reais após análise)
    results = [5, 3, 2]  # Exemplo de contagem por classe
    plot_results(results)
