# pip install torch
# pip install transformers
# pip install librosa
# pip install matplotlib
from transformers import AutoProcessor, WavLMForSequenceClassification
import torch
import librosa
import matplotlib.pyplot as plt
import numpy as np

# Caminho para os arquivos do modelo
MODEL_PATH = r"C:\Users\iliei\OneDrive - ISCTE-IUL\Ambiente de Trabalho\Universidade 2º ano\2º Semestre\Empreendedorimos e Inovaçao II\RestifyV2\ml\modelo"

# Carregar processador e modelo pré-treinado
processor = AutoProcessor.from_pretrained(MODEL_PATH)
model = WavLMForSequenceClassification.from_pretrained(MODEL_PATH)

# Função para pré-processar áudio em segmentos de 5 segundos
def preprocess_audio(audio_path, segment_duration=5):
    signal, sr = librosa.load(audio_path, sr=16000)
    segment_length = segment_duration * sr
    segments = [signal[i:i + segment_length] for i in range(0, len(signal), segment_length)]
    return segments, sr

# Função para classificar cada segmento de áudio
def classify_segments(audio_path):
    segments, sr = preprocess_audio(audio_path)
    results = []
    for segment in segments:
        inputs = processor(segment, sampling_rate=sr, return_tensors="pt", padding=True)
        with torch.no_grad():
            outputs = model(**inputs)
        logits = outputs.logits
        predicted_class = torch.argmax(logits, dim=-1).item()
        results.append(predicted_class)
    return results

# Função para gerar gráfico temporal
def plot_temporal_results(results, segment_duration=5, output_path="temporal_plot.png"):
    classes = ["Apneia", "Ronco", "Falta de Ar", "Normal"]
    time_points = [i * segment_duration for i in range(len(results))]
    plt.figure(figsize=(10, 6))
    plt.plot(time_points, results, marker='o', linestyle='-', label="Classificação")
    plt.yticks(range(len(classes)), classes)
    plt.xlabel("Tempo (segundos)")
    plt.ylabel("Classificação")
    plt.title("Classificação Temporal de Áudio")
    plt.legend()
    plt.grid()
    plt.savefig(output_path)
    plt.show()

# Fluxo completo para processar os arquivos especificados
if __name__ == "__main__":
    audio_files = [
        r"C:\Users\iliei\OneDrive - ISCTE-IUL\Ambiente de Trabalho\Universidade 2º ano\2º Semestre\Empreendedorimos e Inovaçao II\RestifyV2\ml\apneiaSample2.mp3",
        r"C:\Users\iliei\OneDrive - ISCTE-IUL\Ambiente de Trabalho\Universidade 2º ano\2º Semestre\Empreendedorimos e Inovaçao II\RestifyV2\ml\snoreVSapneiaSound.mp3"
    ]

    for audio_path in audio_files:
        results = classify_segments(audio_path)
        print(f"Resultados para {audio_path}: {results}")
        plot_temporal_results(results, output_path=f"{audio_path.split('\\')[-1].replace('.mp3', '_plot.png')}")
